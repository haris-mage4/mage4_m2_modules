<?php

namespace Baytonia\BulkProductSyncToOddo\Console\Command;

use Magento\Framework\Exception\NoSuchEntityException;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\File\Csv;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Catalog\Model\ProductRepository;
use Webkul\Odoomagentoconnect\Model\Template;
use Webkul\Odoomagentoconnect\Model\ResourceModel\Template as TemplateResource;
use Webkul\Odoomagentoconnect\Model\Product;
use Webkul\Odoomagentoconnect\Model\ResourceModel\Product as ProductResource;
use Baytonia\BulkProductSyncToOddo\Model\ReportFactory;
use Magento\Framework\Filesystem;

class Test extends Command
{
    private const NAME = 'name';

    /**
     * @var Csv
     */
    protected $csv;

    /**
     * @var DirectoryList
     */
    protected $fileDirectory;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * @var Template
     */
    protected $templateMapping;

    /**
     * @var TemplateResource
     */
    protected $templateModel;

    /**
     * @var Product
     */
    protected $productMapping;

    /**
     * @var ProductResource
     */
    protected $productModel;

    /**
     * @var ReportFactory
     */
    protected $reportModel;

    /**
     * @var Filesystem
     */
    protected $fileSystem;

    protected $directory;

    public function __construct(Filesystem $filesystem, ReportFactory $reportModel, ProductResource $productModel, Product $productMapping, TemplateResource $templateModel, Template $templateMapping, ProductRepository $productRepository, DirectoryList $fileDirectory, Csv $csv, string $name = null)
    {
        $this->csv = $csv;
        $this->fileDirectory = $fileDirectory;
        $this->productRepository = $productRepository;
        $this->templateMapping = $templateMapping;
        $this->templateModel = $templateModel;
        $this->productMapping = $productMapping;
        $this->productModel = $productModel;
        $this->reportModel = $reportModel;
        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        parent::__construct($name);
    }

    protected function configure(): void
    {
        $this->setName('baytonia:test:command');
        $this->setDescription('This is my first console command.');
        $this->addOption(
            self::NAME,
            null,
            InputOption::VALUE_REQUIRED,
            'Name'
        );

        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {

        $directoryRoot = $this->fileDirectory->getRoot();
      //  $csvFilename = trim($importFile);
        $csv = $directoryRoot . '/' . 'var/import_history/' . 'file14092022.csv';
        $data = $this->csv->getData($csv);
        $model = $this->reportModel->create();
        $model->addReport(str_replace('"', "", 'file14092022.csv'));
        $model->setStatus('In progess');
        $model->save();
        $productSkus = [];
        $record = [];
        $m = null;
        $status = '';
        foreach ($data as $row => $d) {
            if ($row > 0) {
                $sku = $d[0];
                $productSkus[] = $sku;

                try {
                    $product = $this->productRepository->get($sku);
                    $productId = $product->getId();

                    $output->writeln(
                        '<info>Row: ' . $row .
                        ' Product: ' . $sku .
                        ' - ' .
                        $productId
                        . '</info>');
                    if ($product->getTypeId() == "configurable") {
                       echo "333 8";
                        $mapping = $this->templateMapping->getCollection()
                            ->addFieldToFilter('magento_id', ['eq' => $productId]);
                        $templateObj = $this->templateModel;
                        if ($mapping->getSize() == 0) {
                            echo "333 1";
                            $response = $templateObj->exportSpecificConfigurable($productId);
                            if ($response['odoo_id'] > 0) {
                                $erpTemplateId = $response['odoo_id'];
                                $templateObj->syncConfigChildProducts($productId, $erpTemplateId);
                            } else {
                                echo "333 2";
                            }
                        } else {
                            echo "333";
                            foreach ($mapping as $mageObj) {
                                echo "333 6";
                                $response = $templateObj->updateConfigurableProduct($mageObj);
                                if ($response['odoo_id'] > 0) {
                                    echo "333 5";
                                } else {
                                    echo "333 4";
                                }
                            }
                        }
                    } else {
                        echo "333 4 551 " . $productId . ' - ' ;
                        $mapping = $this->productMapping->getCollection()
                            ->addFieldToFilter('magento_id', ['eq' => $productId]);
                      //  print_r($mapping->getSize());
                        $productObj = $this->productModel;
                        if ($mapping->getSize() == 0) {
                            echo "333 4 88";
                            $response = $productObj->createSpecificProduct($productId);
                            if ($response['odoo_id'] > 0) {
                                echo "333 4 556";
                            } else {
                                echo "333 4 88";
                            }
                        } else {

                            foreach ($mapping as $mageObj) {

                                $response = $productObj->updateNormalProduct($mageObj);
                                if ($response['odoo_id'] > 0) {
                                    echo "333 4 77 ";
                                } else {
                                    echo ' nooooo';
                                }
                                echo "333 4 55";
                            }
                        }
                    }
                    $record[] = ['sku' => $sku, 'status' => 'Success'];
                    $status = 'Success';
                    $m = null;
                   // $this->writeReport($model, $record, 'file14092022.csv', $status, $m);
                } catch (\Exception $exception) {
                    $status = 'Missing';
                    $m = $exception->getMessage();
                    $record[] = ['sku' => $sku, 'status' =>  'Fail'];
                  //  $this->writeReport($model, $record, 'file14092022.csv', $status, $m);
                    //$this->logger->info($exception->getMessage());
                    $output->writeln(
                        '<error>Row: ' . $row .
                        ' Product: ' . $sku .
                        ' - ' .
                        $exception->getMessage()
                        . '</error>');
                }
            }
        }
        $this->writeReport($model, $record, 'file14092022.csv', $status, $m);
    }

    private function writeReport($model, $productSkus, $csvFilename, $status, $m)
    {
        $reportFilename = 'report_' . $csvFilename;
        $filepath = 'import_history/' . $reportFilename;
        //$this->directory->create('reports');
        $stream = $this->directory->openFile($filepath, 'w+');
        $stream->lock();
        $header = ['Sku', 'Status','error'];
        $stream->writeCsv($header);
        foreach ($productSkus as $skus) {
            $data = [];
            $data[] = $skus['sku'];
            $data[] = $skus['status'];
            $data[] = $m;
            $stream->writeCsv($data);
        }
        $model->addReportFile($reportFilename);
        $model->setStatus('Completed');
        $model->save();
    }
}
