<?php

namespace Baytonia\BulkProductSyncToOddo\Observer;

use Magento\Framework\App\RequestInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface;
use Baytonia\BulkProductSyncToOddo\Model\Publisher;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\User\Model\UserFactory;
use Magento\ImportExport\Model\History;

/**
 * @class CreateQueue
 */
class CreateQueue implements ObserverInterface
{
    /**
     * @var LoggerInterface
     */
    protected $logger;
    /**
     * @var Publisher
     */
    protected $baytoniaPublisher;
    /**
     * @var Json
     */
    protected $json;

    /**
     * @var RequestInterface
     */
    protected $request;

    /**
     * @var History
     */
    protected $history;

    protected $userFactory;

    /**
     * @param LoggerInterface $logger
     * @param Publisher $baytoniaPublisher
     * @param Json $json
     */
    public function __construct(UserFactory $userFactory, LoggerInterface $logger, Publisher $baytoniaPublisher, Json $json, RequestInterface $request, History $history)
    {
        $this->userFactory = $userFactory;
        $this->logger = $logger;
        $this->baytoniaPublisher = $baytoniaPublisher;
        $this->json = $json;
        $this->request = $request;
        $this->history = $history;
    }

    /**
     * @param Observer $observer
     * @return void
     */
    public function execute(Observer $observer)
    {
     $event = $observer->getEvent();
     $this->logger->info('test event ' . $event->getName());
        $userName = $this->userFactory->create()->load($this->history->getUserId())->getUserName();
	  $bodyParams = [
          'username' => $userName,
          'imported_filename' =>   $this->history->getImportedFile()
        ]; 
        $this->baytoniaPublisher->execute($this->json->serialize($bodyParams));
    }
}
