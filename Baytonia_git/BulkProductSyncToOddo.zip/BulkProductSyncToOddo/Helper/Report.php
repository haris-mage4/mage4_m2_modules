<?php

namespace Baytonia\BulkProductSyncToOddo\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\Exception\ValidatorException;
use Baytonia\BulkProductSyncToOddo\Model\Report as ReportModel;
use Magento\Framework\Filesystem\Directory\ReadInterface;

class Report extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Framework\Stdlib\DateTime\Timezone
     */
    protected $timeZone;

    /**
     * @var \Magento\Framework\Filesystem\Directory\WriteInterface
     */
    protected $varDirectory;

    /**
     * @var ReadInterface
     */
    private $reportsDirectory;

    public function __construct(Context                                     $context,
                                \Magento\Framework\Stdlib\DateTime\Timezone $timeZone,
                                \Magento\Framework\Filesystem               $filesystem
    )
    {
        $this->timeZone = $timeZone;
        $this->varDirectory = $filesystem->getDirectoryWrite(DirectoryList::VAR_IMPORT_EXPORT);
        $reportsPath = $this->varDirectory->getAbsolutePath('import_history');
        $this->reportsDirectory = $filesystem->getDirectoryReadByPath($reportsPath);
        parent::__construct($context);
    }

    /**
     * Checks imported file exists.
     *
     * @param string $filename
     * @return bool
     */
    public function importFileExists($filename)
    {
        return $this->varDirectory->isFile($this->getFilePath($filename));
    }

    /**
     * Get file path.
     *
     * @param string $filename
     * @return string
     * @throws \InvalidArgumentException
     */
    protected function getFilePath($filename)
    {
        try {
            $filePath = $this->varDirectory->getRelativePath($this->reportsDirectory->getAbsolutePath($filename));
        } catch (ValidatorException $e) {
            throw new \InvalidArgumentException('File not found');
        }
        return $filePath;
    }

    /*
    **
    * Get report file output
    *
    * @param string $filename
    * @return string
    */
    public function getReportOutput($filename)
    {
        return $this->varDirectory->readFile($this->getFilePath($filename));
    }

    /**
     * Retrieve report file size
     *
     * @param string $filename
     * @return int|null
     */
    public function getReportSize($filename)
    {

        $statResult = $this->varDirectory->stat($this->getFilePath($filename));
        return $statResult['size'] ?? null;
    }

}
