<?php
/**
 * Copyright © Baytonia, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Baytonia\BulkProductSyncToOddo\Model;


/**
 * Report model
 *
 * @api
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.LongVariable)
 * @since 100.0.2
 */
class Report extends \Magento\Framework\Model\AbstractModel
{
    const ID = 'id';

    const ADMIN_USER = 'user';

    const IMPORTED_FILE = 'importedfile';

    const REPORT_FILE = 'reportfile';

    const IMPORT_SCHEDULED_USER = '';

    /**
     * @var \Magento\ImportExport\Helper\Report
     */
    protected $reportHelper;

    /**
     * @var \Magento\Backend\Model\Auth\Session
     * @since 100.3.1
     */
    protected $session;

    /**
     * Class constructor
     *
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report $resource
     * @param \Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report\Collection $resourceCollection
     * @param \Magento\ImportExport\Helper\Report $reportHelper
     * @param \Magento\Backend\Model\Auth\Session $authSession
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report $resource,
        \Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report\Collection $resourceCollection,
        \Magento\ImportExport\Helper\Report $reportHelper,
        \Magento\Backend\Model\Auth\Session $authSession,
        array $data = []
    ) {
        $this->reportHelper = $reportHelper;
        $this->session = $authSession;

        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Initialize report resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report::class);
    }

    /**
     * Add  report
     *
     * @param string $filename
     * @return $this
     */
    public function addReport($filename)
    {
        $this->addImportedFileAndStatus($filename);
        return $this;
    }

    /**
     * Add  reports
     *
     * @param string $filename
     * @return $this
     */
    public function addReportFile($filename)
    {
        $this->setReportFile($filename);
        $this->save();
        return $this;
    }

    /**
     * Get import history report ID
     *
     * @return string
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * Get report ID
     *
     * @return string
     */
    public function getAdminUser()
    {
        return $this->getData(self::ADMIN_USER);
    }

    /**
     * Get  report ID
     *
     * @return string
     */
    public function getImportedfile()
    {
        return $this->getData(self::IMPORTED_FILE);
    }


    /**
     * Get error file
     *
     * @return string
     */
    public function getReportfile()
    {
        return $this->getData(self::REPORT_FILE);
    }

    /**
     * Get status
     * @param string $status
     * @return $this
     */
    public function getStatus()
    {
        return $this->getData('status');
    }


    /**
     * Set report ID
     *
     * @param int $id
     * @return $this
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }
        /**
     * Set imported file name
     *
     * @param string $importedFile
     * @return $this
     */
    public function addImportedFileAndStatus($importedFile)
    {
        return $this->addData([self::IMPORTED_FILE => $importedFile]);
    }

    /**
     * Set error file name
     *
     * @param string $reportFile
     * @return $this
     */
    public function setReportFile($reportFile)
    {
        return $this->setData(self::REPORT_FILE, $reportFile);
    }

    /**
     * Set admin user
     * @param string $user
     * @return $this
     */
    public function setAdminUser($user)
    {
        return $this->setData(self::ADMIN_USER, $user);
    }

    /**
     * Set status
     * @param string $status
     * @return $this
     */
    public function setStatus($status)
    {
        return $this->setData('status', $status);
    }

}
