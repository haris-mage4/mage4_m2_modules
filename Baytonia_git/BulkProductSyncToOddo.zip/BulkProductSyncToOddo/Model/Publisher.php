<?php

namespace Baytonia\BulkProductSyncToOddo\Model;

use Magento\Framework\MessageQueue\PublisherInterface;


class Publisher
{
    protected $publisher;
    const TOPIC_NAME = 'baytonia.odoo.products.bulk.syncing';

    public function __construct(
        PublisherInterface $publisher
    )
    {
        $this->publisher = $publisher;
    }
    public function execute($data){
        $this->publisher->publish(self::TOPIC_NAME, $data);
    }
}
