<?php
/**
 * Copyright © Baytonia, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report;

use \Baytonia\BulkProductSyncToOddo\Model\Report;

/**
 * Import report collection
 *
 * @api
 * @since 100.0.2
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Link table name
     *
     * @var string
     */
    protected $_linkTable;

    /**
     * Define resource model and assign link table name
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Baytonia\BulkProductSyncToOddo\Model\Report::class,
            \Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report::class
        );
      //  $this->_linkTable = $this->getTable('admin_user');
    }

    /**
     * Init select
     *
     * @return \ Baytonia\BulkProductSyncToOddo\Model\ResourceModel\Report\Collection
     */
    protected function _initSelect()
    {
        parent::_initSelect();
//        $this->getSelect()->joinLeft(
//            ['link_table' => $this->_linkTable],
//            'link_table.user_id = main_table.user_id',
//            ['username']
//        )->where(
//            'execution_time != ? OR (error_file != "" AND execution_time = ?)',
//            History::IMPORT_VALIDATION,
//            History::IMPORT_VALIDATION
//        );
        $this->getSelect()->order('id DESC');
        return $this;
    }
}
