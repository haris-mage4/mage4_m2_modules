<?php

namespace Baytonia\BulkProductSyncToOddo\Model;

use Baytonia\BulkProductSyncToOddo\Model\ReportFactory;
use Magento\Catalog\Model\Product as CatalogProduct;
use Magento\Catalog\Model\Product\Option;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\File\Csv;
use Magento\Framework\Filesystem;
use Psr\Log\LoggerInterface;
use Magento\Framework\Serialize\Serializer\Json;
use Webkul\Odoomagentoconnect\Helper\Connection;
use Webkul\Odoomagentoconnect\Model\Product as WebkulProduct;
use Webkul\Odoomagentoconnect\Model\ResourceModel\Product as WelkulResourceProduct;
use Webkul\Odoomagentoconnect\Model\Template;
use Webkul\Odoomagentoconnect\Model\ResourceModel\Template as ResourceTemplate;

/**
 *
 */
class Consumer
{
    /**
     * @var LoggerInterface
     */
    protected $logger;
    /**
     * @var Json
     */
    protected $json;

    /**
     * @var Option
     */
    protected $_options;
    /**
     * @var Connection
     */
    protected $_connection;

    /**
     * @var Json
     */
    protected $_templateMapping;

    /**
     * @var Template
     */
    protected $_templateModel;

    /**
     * @var WebkulProduct
     */
    protected $_productMapping;

    /**
     * @var WelkulResourceProduct
     */
    protected $_productModel;

    /**
     * @var CatalogProduct
     */
    protected $_catalogModel;

    /**
     * @var ProductRepository
     */
    protected $_productRepository;

    /**
     * @var Filesystem
     */
    protected $fileSystem;

    protected $directory;

    /**
     * @var Csv
     */
    protected $csv;

    /**
     * @var DirectoryList
     */
    protected $fileDirectory;

    /**
     * @var ReportFactory
     */
    protected $reportModel;

    public function __construct(
        ReportFactory         $reportModel,
        Csv                   $csv,
        DirectoryList         $fileDirectory,
        Filesystem            $filesystem,
        LoggerInterface       $logger,
        Json                  $json,
        Option                $options,
        Connection            $connection,
        Template              $templateMapping,
        ResourceTemplate      $templateModel,
        WebkulProduct         $productMapping,
        WelkulResourceProduct $productModel,
        CatalogProduct        $catalogModel,
        ProductRepository     $productRepository)
    {
        $this->logger = $logger;
        $this->json = $json;
        $this->_options = $options;
        $this->_connection = $connection;
        $this->_templateMapping = $templateMapping;
        $this->_templateModel = $templateModel;
        $this->_productMapping = $productMapping;
        $this->_productModel = $productModel;
        $this->_catalogModel = $catalogModel;
        $this->_productRepository = $productRepository;
        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        $this->reportModel = $reportModel;
        $this->csv = $csv;
        $this->fileDirectory = $fileDirectory;
    }

    /**
     * @param  $importFile
     * @return void
     */
    public function process($importFile)
    {
        $this->logger->info($importFile);
    	$this->logger->info('test queue');
        $this->syncingProductsOdoo($importFile);
    }

    /**
     * @param $product
     */
    private function syncingProductsOdoo($data)
    {
        $params = $this->json->unserialize($data);
        $this->logger->info($params['username']);
        $this->logger->info($params['imported_filename']);
        $username = $params['username'];
        $importFile = $params['imported_filename'];
        $directoryRoot = $this->fileDirectory->getRoot();
        $csvFilename = trim($importFile);
        $csv = $directoryRoot . '/' . 'var/import_history/' . $csvFilename;
        $csvData = $this->csv->getData($csv);
        $model = $this->reportModel->create();
        $model->addReport(str_replace('"', "", $importFile));
        $model->setStatus('In progess');
        $model->setAdminUser($username);
        $model->save();
        $record = [];
        foreach ($csvData as $row => $d) {
            if ($row > 0) {
                $sku = $d[0];
                try {
                    $product = $this->_productRepository->get($sku);
                    $productId = $product->getId();

                    $this->logger->info(
                        'Row: ' . $row .
                        ' Product: ' . $sku .
                        ' - ' .
                        $productId
                    );
                    if ($product->getTypeId() == "configurable") {
                        $mapping = $this->_templateMapping->getCollection()
                            ->addFieldToFilter('magento_id', ['eq' => $productId]);
                        $templateObj = $this->_templateModel;
                        if ($mapping->getSize() == 0) {
                            $response = $templateObj->exportSpecificConfigurable($productId);
                            if ($response['odoo_id'] > 0) {
                                $erpTemplateId = $response['odoo_id'];
                                $templateObj->syncConfigChildProducts($productId, $erpTemplateId);
                            } else {
                            }
                        } else {
                            foreach ($mapping as $mageObj) {
                                $response = $templateObj->updateConfigurableProduct($mageObj);
                                if ($response['odoo_id'] > 0) {
                                } else {
                                }
                            }
                        }
                    } else {
                        $mapping = $this->_productMapping->getCollection()
                            ->addFieldToFilter('magento_id', ['eq' => $productId]);

                        $productObj = $this->_productModel;
                        if ($mapping->getSize() == 0) {
                            $response = $productObj->createSpecificProduct($productId);
                            if ($response['odoo_id'] > 0) {
                            } else {
                            }
                        } else {

                            foreach ($mapping as $mageObj) {

                                $response = $productObj->updateNormalProduct($mageObj);
                                $this->logger->info($response['odoo_id'] . ' --');
                                if ($response['odoo_id'] > 0) {
                                } else {
                                }
                            }
                        }
                    }
                    $m = 'null';
                    $record[] = ['sku' => $sku, 'status' => 'Success', 'error' => $m];
                } catch (\Exception $exception) {
                    $m = $exception->getMessage();
                    $record[] = ['sku' => $sku, 'status' => 'Missing', 'error' => $m];
                    $this->logger->info($exception->getMessage());
                }
            }
        }
        $this->writeReport($model, $record, $csvFilename);
    }

    private function writeReport($model, $productSkus, $csvFilename)
    {
        $reportFilename = 'report_' . $csvFilename;
        $filepath = 'import_history/' . $reportFilename;
        $stream = $this->directory->openFile($filepath, 'w+');
        $stream->lock();
        $header = ['Sku', 'Status', 'Error'];
        $stream->writeCsv($header);
        foreach ($productSkus as $skus) {
            $data = [];
            $data[] = $skus['sku'];
            $data[] = $skus['status'];
            $data[] = $skus['error'];
            $stream->writeCsv($data);
        }
        $model->addReportFile($reportFilename);
        $model->setStatus('Completed');
        $model->save();
    }

}
