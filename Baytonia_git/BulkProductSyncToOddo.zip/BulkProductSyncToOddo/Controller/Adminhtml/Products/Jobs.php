<?php

namespace Baytonia\BulkProductSyncToOddo\Controller\Adminhtml\Products;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpGetActionInterface as HttpGetActionInterface;
use Magento\Framework\Controller\ResultFactory;

class Jobs extends \Magento\Backend\App\Action implements HttpGetActionInterface
{
    protected $resultFactory;

    public function __construct(ResultFactory $resultFactory , Context $context)
    {
        $this->resultFactory = $resultFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $page = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
        $page->setActiveMenu('Baytonia_BulkProductSyncToOddo::jobs');
        $page->getConfig()->getTitle()->prepend(__('Products Syncing To Odoo'));
        return $page;
    }
}
