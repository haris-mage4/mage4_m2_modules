<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Baytonia\BulkProductSyncToOddo\Block\Adminhtml\Grid\Column\Renderer\Importedfile;

use Magento\ImportExport\Model\Import;

/**
 * Backup grid item renderer
 */
class Download extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\Text
{
    /**
     * Renders grid column
     *
     * @param \Magento\Framework\DataObject $row
     * @return mixed
     */
    public function _getValue(\Magento\Framework\DataObject $row)
    {
        $result = '';
        if ($row->getData('importedfile') != '') {
            $result = '<p> ' . $this->escapeHtml($row->getData('importedfile')) .  '</p><a href="'
                . $this->getUrl('*/*/download', ['filename' => $row->getData('importedfile')]) . '">'
                . $this->escapeHtml(__('Download'))
                . '</a>';
        }
        return $result;
    }
}
