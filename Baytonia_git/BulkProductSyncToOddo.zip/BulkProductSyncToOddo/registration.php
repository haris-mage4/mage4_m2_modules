<?php

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Baytonia_BulkProductSyncToOddo',
    __DIR__
);
